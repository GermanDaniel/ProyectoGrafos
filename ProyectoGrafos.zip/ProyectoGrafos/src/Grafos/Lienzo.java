/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Grafos;

import java.awt.Graphics;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.util.Vector;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

/**
 *
 * @author Daniel Alvarez
 */
public class Lienzo extends JPanel implements MouseListener, MouseMotionListener{
    private Vector<Nodo> vectorNodos;//crear una lista con un vector que contenga los nodos que vayamos creando en el lienzo
    private Vector<Enlace> vectorEnlaces;//crear un vetor que contenga los enlaces
    private Point p1, p2;//crear unas variables de tipo point
    private Nodo nodoMover;//variable nodo mover
    private int iNodo;

    //creamos nuestro constructor No pasamos nada por parametro
    public Lienzo(){
        this.vectorNodos=new Vector<>();//inicializar nuestro vector de nodos
        this.vectorEnlaces=new Vector<>();
        this.addMouseMotionListener(this);
        this.addMouseListener(this);//este es el que identifica las acciones que hacemos con el mouse
    }
    //creamos un metodo abstracto que recive parametro tipo graphics
    public void paint(Graphics g){
        super.paint(g);
        for (Nodo nodos : vectorNodos) {//for que recorra nuestros nodos y los vaya pintando
            nodos.pintar(g);
        }
        for (Enlace enlace : vectorEnlaces) {//for que recorra nuestros vector de enlaces
            enlace.pintar(g);
        }
    }
    @Override
    public void mouseClicked(MouseEvent e) {
        if(e.getButton()==MouseEvent.BUTTON1){//click izquierdo quien identifique para pintar
            String nombre = JOptionPane.showInputDialog("Ingrese nombre nodo: ");//herramienta de dialogo pararescatar valores que deseamos
            this.vectorNodos.add(new Nodo(e.getX(), e.getY(), nombre));//crear un nuevo objeto y agregarlo al vector, agregamos un 
                                                                       //nuevo nodo al hacer click en cualquier lugar del panel
            repaint();//repintamos nuestro lienzo cada vez que pintemos un nuevo nodo
        }
        if(e.getButton() == MouseEvent.BUTTON3){//click derecho me pinte
            for (Nodo nodo : vectorNodos) {//recorremos nuestro vector de nodos
                
                //para ver si estamos sobre el circulo 
                //constains si el punto donde estamos dando clik es correcto
                if(new Rectangle(nodo.getX() - Nodo.d/2, nodo.getY() - Nodo.d/2, Nodo.d, Nodo.d).contains(e.getPoint())){
                    if(p1 == null){
                        p1 = new Point(nodo.getX(), nodo.getY());//tenemos que inicilizar
                    }else{
                        p2 = new Point(nodo.getX(), nodo.getY());
                        String nombre = JOptionPane.showInputDialog("Ingrese valor arista: ");
                        this.vectorEnlaces.add(new Enlace(p1.x, p1.y, p2.x, p2.y, nombre));//agregar un nuevo enlace a nuestro vector enlace
                        repaint();//repintamos para que actualize nuestro lienzo
                        p1 = null;//para que podamos seguir pintando volvemos a poner en null ambos
                        p2 = null;
                    }
                }
            }
        }
    }

    @Override
    public void mousePressed(MouseEvent e) {
        int iN = 0;
        for (Nodo nodo : vectorNodos) {
            //si estamos en la posicion de un nodo en el lienzo
            if(new Rectangle(nodo.getX() - Nodo.d/2, nodo.getY() - Nodo.d/2, Nodo.d, Nodo.d).contains(e.getPoint())){
                nodoMover = nodo;//inicializamos nuestro objeto nodo
                iNodo = iN;
                break;//nos salimos cuando esto ocurra en nuestro ciclo
            }
            iN++;
        }
    }

    @Override
    public void mouseReleased(MouseEvent e) {
        //cuando soltamos el boton presionado y tenemos que hacer como un reset osea volver a sus valores iniciales
        nodoMover = null;
        iNodo = -1;
    }

    @Override
    public void mouseEntered(MouseEvent e) {

    }

    @Override
    public void mouseExited(MouseEvent e) {
        
    }

    @Override
    public void mouseDragged(MouseEvent e) {
        if(nodoMover != null){
            //modificamos el elemento del vector de nodos para esto utilizamos set
            this.vectorNodos.set(iNodo, new Nodo(e.getX(), e.getY(), nodoMover.getNombre()));
            int iE = 0;//declaramos un contador
            for (Enlace enlace : vectorEnlaces) {//recorremos con un for
                //para detectar el nodo
                if(new Rectangle(enlace.getX1() - Nodo.d/2, enlace.getY1()-Nodo.d/2, Nodo.d, Nodo.d).contains(e.getPoint())){
                    this.vectorEnlaces.set(iE, new Enlace(e.getX(), e.getY(), enlace.getX2(), enlace.getY2(), enlace.getNombre()));
                }else if(new Rectangle(enlace.getX2() - Nodo.d/2, enlace.getY2()-Nodo.d/2, Nodo.d, Nodo.d).contains(e.getPoint())){
                    this.vectorEnlaces.set(iE, new Enlace(enlace.getX1(), enlace.getY1(), e.getX(), e.getY(), enlace.getNombre()));
                }
                iE++;
            }
        }
        repaint();
    }

    @Override
    public void mouseMoved(MouseEvent e) {

    }
    
}
