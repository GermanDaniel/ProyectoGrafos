/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Grafos;

import java.awt.Graphics;

/**
 *
 * @author Daniel Alvarez
 */
public class Nodo {
    private int x, y;//dos variables que representa nuestras coordenadas de nuestro vertice
    private String nombre;//creams variable tipo string
    public static final int d=60;// diametro de nuestro circulo con un valor de 60 puntos
    
    //constructor generado automaticamente al cual va a recibir en parametro x, y, nombre
    public Nodo(int x, int y, String nombre) {
        this.x = x;
        this.y = y;
        this.nombre = nombre;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void pintar(Graphics g){
        g.drawOval(this.x - d/2,this.y - d/2, d, d);//dibujar un circulo 
        g.drawString(nombre, x, y);//
    }
    
    public int getX() {
        return x;
    }

    public void setX(int x) {
        this.x = x;
    }

    public int getY() {
        return y;
    }

    public void setY(int y) {
        this.y = y;
    }

}
