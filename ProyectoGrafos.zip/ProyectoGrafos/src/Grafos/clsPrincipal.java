/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Grafos;

import javax.swing.JFrame;

/**
 *
 * @author Daniel Alvarez
 */
public class clsPrincipal {
    
    public static void main(String[] args) {
        JFrame ventana = new JFrame("Proyecto Grafo");//creamos una nueva ventana
        ventana.add(new Lienzo());//agregamos un nuevo lienzo
        ventana.setSize(600,600);//indicamos un tamaño
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);//cada vez que cerremos nuestra ventana se cierre todo el programa
        ventana.setVisible(true);//mostrar nuestra ventana
    }
}
